<div class="container">
    <form action="" method="post">
        <legend>Tambah Data Penduduk</legend>
        <div class="mb-3">
            <label for="penduduk" class="form-label">Nama Penduduk</label>
            <input type="text" class="form-control" id="penduduk" name="penduduk" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('penduduk'); ?></div>
        </div>
        <input type="submit" value="submit" class="btn btn-primary"></input>
    </form>
</div>