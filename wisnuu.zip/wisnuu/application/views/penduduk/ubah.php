<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Penduduk</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $penduduk['id']; ?>">
            <label for="penduduk" class="form-label">Nama Penduduk</label>
            <input type="text" class="form-control" id="penduduk" name="penduduk" value="<?= $penduduk['penduduk']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('penduduk'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>