<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penduduk extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_penduduk');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Penduduk';

        $data['penduduk'] = $this->Model_penduduk->getAllPenduduk();
        if( $this->input->post('keyword') ) {
            $data['penduduk'] = $this->Model_penduduk->CariPenduduk();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('penduduk/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('penduduk', 'Penduduk', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Penduduk';

            $this->load->view('templates/header.php', $data);
            $this->load->view('penduduk/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_penduduk->TambahPenduduk();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('penduduk');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('penduduk', 'Penduduk', 'trim|required');
        $data['penduduk'] = $this->Model_penduduk->getPendudukById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah Penduduk';

            $this->load->view('templates/header.php', $data);
            $this->load->view('penduduk/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_penduduk->UbahPenduduk();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('penduduk');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_penduduk->hapusPenduduk($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('penduduk');
    }
}
