<?php
class Model_penduduk extends CI_Model 
{
    public function getAllPenduduk()
    {
        return $query = $this->db->get('penduduk')->result_array();
    }

    public function Tambahpenduduk()
    {
        $data = [
            "penduduk" => $this->input->post('penduduk', true)
        ];

        $this->db->insert('penduduk', $data);
    }

    public function Ubahpenduduk()
    {
        $data = [
            "penduduk" => $this->input->post('penduduk', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('penduduk', $data);
    }

    public function hapuspenduduk($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('penduduk');
    }

    public function getPendudukById($id)
    {
        return $this->db->get_where('penduduk', ['id' => $id])->row_array();
    }

    public function Caripenduduk()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('penduduk', $keyword);
        return $this->db->get('penduduk')->result_array();
    }
}

?>